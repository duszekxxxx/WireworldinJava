#ifndef LIFE_PNGOPERATOR_H
#define LIFE_PNGOPERATOR_H
#include "gameOperator.h"
/*
 * Function write generated files as PNG file
 *
 */
int printFile(char * fileName, gameBoard_t * gameBoard, int cellSize);
#endif //LIFE_PNGOPERATOR_H
